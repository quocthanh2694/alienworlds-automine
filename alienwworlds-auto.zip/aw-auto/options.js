console.log('From OPTIONS');

const el_input_webhook = document.querySelector('#webhook');
const el_btn_save = document.querySelector('#save');
const el_btn_test = document.querySelector('#test');

chrome.runtime.sendMessage({
  message: 'get_webhook'
}, response => {
  if (response.status === true) {
    el_input_webhook.value = response.payload;
  }
});

el_btn_save.addEventListener('click', () => {
  chrome.runtime.sendMessage({
    message: 'change_webhook',
    payload: el_input_webhook.value,
  }, response => {
    if (response.status === true) {
    }
  });
});

el_btn_test.addEventListener('click', () => {
  // Check el_input_webhook.value is valid URL
  if (!/^http/.test(el_input_webhook.value)) return;

  const data = {
    'username': 'AW Bot',
    'avatar_url': 'https://cdn.discordapp.com/embed/avatars/5.png',
    'embeds': [
      {
        'description': 'Test',
        'color': 16411130
      },
    ]
  };

  fetch(el_input_webhook.value, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  })
  .then(res => {
    console.log(`Webhook is success ${res}`);
  })
  .catch(error => {
    console.log(`Webhook was failed ${error}`);
  });
});
