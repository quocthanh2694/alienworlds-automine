console.log('From POPUP');

document.querySelector('#open-options').addEventListener('click', () => {
  chrome.runtime.openOptionsPage(() => {});
});
