console.log('From BACKGROUND');

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    webhook: '',
  });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && /^http/.test(tab.url)) {
    chrome.scripting.insertCSS({
      target: { tabId },
      files: ['./foreground.css']
    }).then(() => {
      console.log("INJECTED THE FOREGROUND STYLES");

      chrome.scripting.executeScript({
        target: { tabId },
        files: ['./foreground.js']
      }).then(() => {
        console.log("INJECTED THE FOREGROUND SCRIPT");
      }).catch(err => {
        console.log(err);
      });
    }).catch(err => {
      console.log(err);
    });
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.message === 'get_webhook') {
    chrome.storage.local.get('webhook', data => {
      if (chrome.runtime.lastError) {
        sendResponse({
          status: false
        });

        return;
      }
      sendResponse({
        status: true,
        payload: data.webhook,
      })
    });

    return true;
  } else if (request.message === 'change_webhook') {
    chrome.storage.local.set({
      webhook: request.payload
    }, () => {
      if (chrome.runtime.lastError) {
        sendResponse({ status: false });
        return;
      }

      sendResponse({ status: true });
    });

    return true;
  }
});
