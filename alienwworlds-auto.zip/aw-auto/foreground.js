console.log('From FOREGROUND');

if (window.location.hostname.endsWith('.netlify.app')) {
  (function init() {
    // Config
    const ON_SOUND = false; // TODO: Set it to enable/disable sound
    const ON_IMAGE = false; // TODO: Set it to enable/disable images
    const ON_TESTING = true; // TODO: Set it to enable/disable testing UI

    // Constant Message
    const LOG_COLOR = 'color: pink; background: black';
    const MINED_MSG = 'ALIEN WORLDS - Mined Trilium';
    const LOGIN_MSG = 'ALIEN WORLDS';
    const TX_NOT_LOAD_MSG = 'Transaction data could not be loaded';
    // const OUT_OF_CPU_MSG = 'Error: estimated CPU time (0 us) is not less than the maximum billable CPU time for the transaction (0 us)';

    // Constant DOM
    const DOM_ID = {
      NOTIFICATION: 'notification',
      LOGIN_BUTTON: 'login-button',
      HEADER_INFO: 'header-info',
      CLAIM_BUTTON: 'claim-button',
      MINE_BUTTON: 'mine-button',
      TIMER: 'timer',
      TEST: 'test',
      CHECKBOX_AUDIO: 'checkbox-audio',
      CHECKBOX_HIDE_IMG: 'checkbox-hide-img',
      TLM_BALANCE: 'tlm-balance',
      DELAY: 'delay',
    };

    // Constant Time
    const MILISECOND = 1000;
    const SECOND = 60;
    const WORK_TIME = 10 * MILISECOND;
    const ERROR_TIME = 1 * SECOND * MILISECOND;

    // Variables
    let DEFAULT_DELAY_SECOND = 0;
    let RELOAD_TIME = 0;
    let RELOAD_TIME_TEST = 90;
    let isLogined = false;
    let isMined = false;
    let isClaimed = false;
    let isSetReloaded = false;
    let isSetDelayTime = false;

    // Helper function
    function getRemainSeconds() {
      let timerEl = getElementById(DOM_ID.TIMER).textContent.split(':');
      let remainSeconds = Number(timerEl[0]) * SECOND + Number(timerEl[1]);
      let delayInCookie = 0;
      delayInCookie = Number(getCookie("delay"));
      if (delayInCookie > 0) {
        remainSeconds = delayInCookie;
      }
      return remainSeconds;
    }

    function getCookie(cname) {
      let name = cname + "=";
      let decodedCookie = decodeURIComponent(document.cookie);
      let ca = decodedCookie.split(';');
      for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
    }

    function refresh() {
      // Hard reload
      location.reload();
      // Soft reload
      // init();
    }

    function setNextReload(timeout = RELOAD_TIME) {
      setTimeout(function () {
        console.log('%c Set time to reload the page...', LOG_COLOR);
        refresh();
      }, timeout);
      RELOAD_TIME_TEST = timeout / MILISECOND;
    }

    // LocalStorage function
    function getErrorCount() {
      return Number(localStorage.getItem('ERROR_COUNT'));
    }

    function setErrorCount(count) {
      return Number(localStorage.setItem('ERROR_COUNT', count));
    }

    // DOM function
    function getElementById(id) {
      return document.getElementById(id);
    }

    function getTimezone(date) {
      let offset = date.getTimezoneOffset() / 60 * -1;
      if (offset > 0) return `+${offset}`
      if (offset < 0) return `-${offset}`
      return offset.toString();
    }

    // Webhook function
    function webhook() {
      chrome.runtime.sendMessage({
        message: 'get_webhook'
      }, response => {
        if (response.status === true) {
          sendWebHook(response.payload);
        }
      });
    }

    function sendWebHook(WEBHOOK_URL) {
      if (!WEBHOOK_URL) return;

      let walletId = getElementById(DOM_ID.HEADER_INFO).textContent.toLowerCase().replace(`${LOGIN_MSG.toLowerCase()} -`, '').trim();
      let balance = getElementById(DOM_ID.TLM_BALANCE).textContent.trim();

      let date = new Date();
      let desc = '';

      let walletIdStr = `[${walletId}](https://wax.bloks.io/account/${walletId})`;
      let timestampStr = `**Timestamp**: ${date.toLocaleString()} UTC ${getTimezone(date)}`;
      let balanceStr = `**Balance**: ${Number(balance).toFixed(2)} TLM`;

      let notificationPara = getElementById(DOM_ID.NOTIFICATION);
      let notificationParaTxt = notificationPara.textContent;

      if (notificationParaTxt.toLowerCase().match('error')) {
        desc = `:interrobang: @everyone ${walletIdStr} - ${balanceStr} - **Error**: ${notificationParaTxt.toLowerCase()} - ${timestampStr}`;
      } else if (notificationParaTxt.toLowerCase().startsWith(MINED_MSG.toLowerCase())) {
        let minedAmount = notificationParaTxt.replace(MINED_MSG, '').trim();
        desc = `:coin: ${walletIdStr} - **Mined**: ${minedAmount} - ${balanceStr} - ${timestampStr}`;
      } else {
        desc = `:warning: @everyone ${walletIdStr} - ${balanceStr} - **Msg**: ${notificationParaTxt} - ${timestampStr}`;
      }

      const data = {
        'username': 'AW Bot',
        'avatar_url': 'https://cdn.discordapp.com/embed/avatars/5.png',
        'embeds': [
          {
            'description': desc,
            'color': 16411130
          },
        ]
      };

      fetch(WEBHOOK_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })
        .then(data => {
          console.log('%c Webhook is success', LOG_COLOR);
        })
        .catch(error => {
          console.log(`%c Webhook was failed ${error}`, LOG_COLOR);
        });
    }

    // Testing
    if (ON_TESTING) {
      getElementById(DOM_ID.NOTIFICATION).insertAdjacentHTML(
        'afterend',
        `<p id="test" style="${LOG_COLOR}"></p>`,
      );

      let testItv = setInterval(() => {
        RELOAD_TIME_TEST > 0 ? --RELOAD_TIME_TEST : 0;
        let minutes = Math.floor(RELOAD_TIME_TEST / SECOND);
        let seconds = RELOAD_TIME_TEST - minutes * SECOND;

        getElementById(DOM_ID.TEST).innerHTML = `RELOAD_TIME remain: ${RELOAD_TIME_TEST} (${minutes}:${seconds})`;

        if (RELOAD_TIME_TEST <= 0) {
          clearInterval(testItv);
        }
      }, MILISECOND);
    }

    // Disable play sound
    if (!ON_SOUND) {
      console.log('%c Sound is disabling...', LOG_COLOR);
      let cbAudio = getElementById(DOM_ID.CHECKBOX_AUDIO);
      if (!!cbAudio && cbAudio.checked) {
        cbAudio.nextElementSibling.click();
      }
    }

    // Disable image
    if (!ON_IMAGE) {
      console.log('%c Image is disabling...', LOG_COLOR);
      let cb = getElementById(DOM_ID.CHECKBOX_HIDE_IMG);
      if (!!cb && !cb.checked) {
        cb.nextElementSibling.click();
      }
    }

    // Check error
    let errorItv = setInterval(() => {
      console.log('%c Checking error...', LOG_COLOR);
      let notificationPara = getElementById(DOM_ID.NOTIFICATION);
      if (notificationPara.textContent.toLowerCase().match('error')) {
        webhook();

        // If out of CPU, stop checking error for a while
        if (getErrorCount() >= 3) {
          clearInterval(errorItv);
          setErrorCount(0);
          setNextReload(2 * SECOND * MILISECOND);
          return;
        }

        setErrorCount(getErrorCount() + 1);
        setNextReload(SECOND * MILISECOND);
        //refresh();
      }
    }, ERROR_TIME);

    // *** IMPORTANT CODE ***

    let workItv = setInterval(() => {
      // HTML elements
      let loginBtn = getElementById(DOM_ID.LOGIN_BUTTON);
      let headerInfoPara = getElementById(DOM_ID.HEADER_INFO);
      let remainSec = getRemainSeconds();

      // START: Checking flag
      if (isLogined && isSetDelayTime && isMined && isClaimed) {
        if (isSetReloaded) {
          // Stop loop
          console.log('%c Stop loop', LOG_COLOR, new Date().toLocaleString());
          clearInterval(workItv);
        } else {
          // If mined success then set reload page
          let notificationPara = getElementById(DOM_ID.NOTIFICATION);
          let notificationParaTxt = notificationPara.textContent;
          if ((notificationParaTxt.toLowerCase().startsWith(MINED_MSG.toLowerCase())
            || notificationParaTxt.toLowerCase().startsWith(TX_NOT_LOAD_MSG.toLowerCase()))
            && remainSec > 0) {
            console.log(
              '%c Mined success => Set reload page',
              LOG_COLOR,
              new Date().toLocaleString(),
            );
            isSetReloaded = true;
            setNextReload(remainSec * MILISECOND);
            webhook();
          }
        }
        console.log('%c Waiting next work...', LOG_COLOR);
        return;
      }
      // END: Checking flag

      // START: Login
      if (
        headerInfoPara.textContent.toLowerCase() != LOGIN_MSG.toLowerCase() &&
        !isLogined
      ) {
        // Already auto login
        console.log('%c Auto Login...', LOG_COLOR);
        isLogined = true;
      }
      if (!loginBtn.hasAttribute('disabled') && !isLogined) {
        // Need manual login
        console.log('%c Manual Login...', LOG_COLOR);
        isLogined = true;
        loginBtn.click();
        console.log('Click Login', new Date().toLocaleString());
      }
      // END: Login

      if (isLogined) {
        // START: Set delay time
        let delaySec = Number(getElementById(DOM_ID.DELAY).textContent);
        let delayInCookie = 0;
        delayInCookie = Number(getCookie("delay"));
        if ((delaySec > 0 || delayInCookie > 0) && !isSetDelayTime) {
          console.log('%c Set delay time...', LOG_COLOR, new Date().toLocaleString());
          isSetDelayTime = true;
          DEFAULT_DELAY_SECOND = delaySec > 0 ? delaySec: delayInCookie;
          RELOAD_TIME = (DEFAULT_DELAY_SECOND + 25) * MILISECOND;
          RELOAD_TIME_TEST = RELOAD_TIME / MILISECOND;

          // START: Optional Defense Code (to make sure it will be reload)
          setNextReload();
          // END: Optional Defense Code
        }
        // END: Set delay time

        if (isSetDelayTime) {
          // START: Mining
          let mineBtn = getElementById(DOM_ID.MINE_BUTTON);
          if (!mineBtn.hasAttribute('disabled') && !isMined) {
            console.log('%c Mining...', LOG_COLOR);
            isMined = true;
            mineBtn.click();
            console.log('Click Mine', new Date().toLocaleString());
          }
          // END: Mining

          if (isMined) {
            // START: Claiming
            let claimBtn = getElementById(DOM_ID.CLAIM_BUTTON);
            if (!claimBtn.hasAttribute('disabled') && !isClaimed) {
              console.log('%c Claiming...', LOG_COLOR);
              isClaimed = true;
              claimBtn.click();
              console.log('Click Claim', new Date().toLocaleString());
            }
            // END: Claiming
          }
        }
      }
    }, WORK_TIME);
  })();
} else if (window.location.hostname.endsWith('all-access.wax.io')) {
  if (window.location.pathname === '/cloud-wallet/login/') {
    (function () {
      // Allow the popup accepted all requests
      const ALLOW_ACCEPT_ALL = false;

      let WaitForReady = setInterval(function () {
        let tags_i = document.getElementsByTagName("button");
        let contractName = document.getElementsByClassName("origin-app")[0];
        if (ALLOW_ACCEPT_ALL ||
          (contractName && contractName.outerText.includes("Unknown URL"))) {
          for (let i = 0; i < tags_i.length; i++) {
            if (tags_i[i].textContent == "Approve"
              && !tags_i[i].hasAttribute('disabled')) {
              let tags_j = document.getElementsByTagName("input");
              for (let j = 0; j < tags_j.length; j++) {
                if (tags_j[j].value == "remember") {
                  break;
                }
              }
              tags_i[i].click();
              clearInterval(WaitForReady);
              break;
            }
          }
        }
      }, 100);
    })();
  } else if (window.location.pathname === '/cloud-wallet/signing/') {
    (function () {
      // Allow the popup accepted all requests
      const ALLOW_ACCEPT_ALL = false;

      let WaitForReady = setInterval(function () {
        let tags_i = document.getElementsByTagName("button");
        let contractName = document.getElementsByClassName("simple-action-details")[0];
        let contractName2 = document.getElementsByClassName("action-details")[0];
        if (ALLOW_ACCEPT_ALL ||
          (contractName && (contractName.outerText.includes("Call smart contract function m.federation >") ||
            contractName.outerText.includes("Call smart contract function metalwargame >") ||
            contractName.outerText.includes("Call smart contract function metalwarmint >"))
            ||
            (
              contractName2 
              &&  contractName2.outerText.includes('m.federation keyboard_arrow_rightkeyboard_arrow_right mine')
            )
            )) {
          for (let i = 0; i < tags_i.length; i++) {
            if (tags_i[i].textContent == "Approve" &&
              !tags_i[i].hasAttribute('disabled')) {
              let tags_j = document.getElementsByTagName("input");
              for (let j = 0; j < tags_j.length; j++) {
                if (tags_j[j].value == "remember") {
                  break;
                }
              }
              tags_i[i].click();
              clearInterval(WaitForReady);
              break;
            }
          }
        }
      }, 100);
    })();
  }
}
